package com.snhu.sslserver;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.stereotype.Service;




public class Hashing {

	public String sha256(String data) {
		try {
			MessageDigest digest = 
					MessageDigest.getInstance("SHA-256");    // starts hashing algo
			
			byte[] hashBytes = digest.digest(
					data.getBytes(StandardCharsets.UTF_8)   // turns input in bytes
					);
			
			StringBuilder hex = new StringBuilder();
			
			for (byte b : hashBytes) {
				hex.append(String.format("%02x", b & 0xff)); // loop to convert bytes into hex string
			}
			
			return hex.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(
					"SHA-256 is not working" , e
					);
		}
	}
}
