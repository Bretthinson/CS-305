package com.snhu.sslserver;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {
	
	@GetMapping("/hash")
	
	public Map<String, String> getHash(){
		String data = "Brett Hinson, CS-305, Chechsum, 10-15-2026";
		
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			
			byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));
			
			StringBuilder checksum = new StringBuilder();
			
			for (byte b : hashBytes) {
				checksum.append(
						String.format("%02x",  b & 0xff)
						);
			}
			
			Map<String, String> result = 
					new LinkedHashMap<>();
			
			result.put("algorithm",  "SHA-256");
			result.put("data", data);
			result.put("checksum", checksum.toString());
			
			return result;
			
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(
					"SHA-256 is unavailable", e
			);
		}
	}
}
